process.env.TZ = 'UTC';
const jestSetup = async () => {};

module.exports = jestSetup;
