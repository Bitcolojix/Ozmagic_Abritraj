# Donations

First of all, you do not need to donate any money to use this project. It's free, open source, so anyone can use it. You don't have any obligation to donate
to this project.

I give no warranty and accepts no responsibility or liability for the accuracy or the completeness of the information and materials contained in this project. Under no circumstances will I be held responsible or liable in any way for any claims, damages, losses, expenses, costs or liabilities whatsoever (including, without limitation, any direct or indirect damages for loss of profits, business interruption or loss of information) resulting from or arising directly or indirectly from your use of or inability to use this code or any code linked to it, or from your reliance on the information and material on this code, even if I have been advised of the possibility of such damages in advance.

Please note donating fund does not mean I will work for you or develop the features you asked for.

The donated funds will be used for testing the bot or buying gifts for my wife, toys for my daughter and coffee beans for me.

| Cryptocurrencies                                              | Network                   | Address                                                                                           |
| ------------------------------------------------------------- | ------------------------- | ------------------------------------------------------------------------------------------------- |
| ![Donate BNB](https://img.shields.io/badge/Donate-BNB-blue)   | Binance Smart Chain (BSC) | `0x3bb3a5dcba339562a32ca104964a4f2bb3c4dfe2`                                                      |
| ![Donate CAKE](https://img.shields.io/badge/Donate-CAKE-blue) | Binance Smart Chain (BSC) | `0x3bb3a5dcba339562a32ca104964a4f2bb3c4dfe2`                                                      |
| ![Donate XMR](https://img.shields.io/badge/Donate-XMR-blue)   |                           | `8AHYg7fESVXHsaHB1izruqcJ4HJVkrhepWe69fCbB71YakpRfzb61x1A3TR9Ne4FhQVUat6QqeZu8NuVXzQnuAYK2MAbDTS` |
