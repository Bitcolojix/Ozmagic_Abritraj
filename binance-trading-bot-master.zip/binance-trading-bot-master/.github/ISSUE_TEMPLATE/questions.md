---
name: '❓ Question'
about: Question
title: ''
labels: 'question'
assignees: ''
---


<!-- Have you checked the Troubleshooting wiki page? -->
<!-- Please refer the wiki page whether other traders already got answer for you -->
<!-- https://github.com/chrisleekr/binance-trading-bot/wiki/Troubleshooting -->

## Version

<!-- At the bottom of the frontend, you can see "Running Version" with the commit hash. -->
<!-- Please provide the version and commit hash. -->
<!-- If it said "unspecified", then you are running the development mode. Unless you are developing, simple use DockerHub image. -->

## Description

<!-- Provide describe your question. Make sure you search the closed issues before
posting a new question. -->
