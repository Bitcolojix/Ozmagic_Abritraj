const PubSub = require('pubsub-js');

module.exports = { PubSub };
